package com.misw.vinilos.ui.collector

import androidx.compose.foundation.background
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.ListItem
import androidx.compose.material3.ListItemDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.tooling.preview.Preview
import com.misw.vinilos.data.model.Collector
import com.misw.vinilos.ui.theme.VinilosTheme

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun CollectorItemView(collector: Collector) {
    ListItem(
        modifier = Modifier
            .background(MaterialTheme.colorScheme.inverseOnSurface),
        headlineText = {
            Text(
                text = "${collector.name}",
            )
        },
        supportingText = {
            Text(
                text = "${collector.email} - ${collector.telephone}",
            )
        },
        colors = ListItemDefaults.colors(
            containerColor = MaterialTheme.colorScheme.inverseOnSurface
        ),
    )
}

@Composable
@Preview(showBackground = true)
fun CollectorItemPreview() {
    VinilosTheme(darkTheme = true) {
        CollectorItemView(
            Collector(
                id = "1",
                name = "Collector name",
                telephone = "+573102178976",
                email = "j.monsalve@gmail.com"
            )
        )
    }
}