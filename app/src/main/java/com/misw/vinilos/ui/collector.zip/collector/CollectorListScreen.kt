package com.misw.vinilos.ui.collector

import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.Divider
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.tooling.preview.Preview
import com.misw.vinilos.data.model.Collector
import com.misw.vinilos.ui.theme.VinilosTheme

@Composable
fun CollectionListScreen(collectorList: List<Collector>) {
    LazyColumn{
        items(items = collectorList){ collector ->
            CollectorItemView(collector)
            Divider(color = Color.Black)
        }
    }
}

@Composable
@Preview
fun CollectionListScreenPreview() {
    VinilosTheme(darkTheme = true) {
        CollectionListScreen(
            listOf(
                Collector(
                    id = "1",
                    name = "Collector name",
                    telephone = "+573102178976",
                    email = "j.monsalve@gmail.com"
                ),
                Collector(
                    id = "1",
                    name = "Collector name",
                    telephone = "+573102178976",
                    email = "j.monsalve@gmail.com"
                )
            )
        )
    }
}
